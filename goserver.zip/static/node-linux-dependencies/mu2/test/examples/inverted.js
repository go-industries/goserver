{
  admin: false,
  person: {
    name: "Jim"
  }
}
