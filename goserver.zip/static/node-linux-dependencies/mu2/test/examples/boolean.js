{
  name: 'Jim',
  age: 24,
  admin: true
}