{
  today: new Date(2012, 0, 1),

  year: function () {
    return this.__date.getFullYear();
  }
}
