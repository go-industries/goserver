(cd test/ && node run_examples_test.js)
(cd test/ && node run_examples_test_no_root.js)
