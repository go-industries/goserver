# side-channel
Store information about any JS value in a side channel. Uses WeakMap if available.
