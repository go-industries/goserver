module.exports = require('util').inspect;
